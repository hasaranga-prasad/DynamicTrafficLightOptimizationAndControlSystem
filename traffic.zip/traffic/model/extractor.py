# import all necessary libraries
from common.utils import *


def get_feature(img, cspace='RGB', spatial_size=(64, 64), hist_bins=32, orient=9,
                pix_per_cell=8, cell_per_block=2, hog_channels=0,
                spatial_feat=True, hist_feat=True, hog_feat=True):
    # convert the image
    image = convert_color(img, cspace)

    # get the spatial features
    if spatial_feat == True:
        spatial_features = bin_spatial(image, size=spatial_size)

    # get the histogram of colors
    if hist_feat == True:
        hist_features = color_hist(image, nbins=hist_bins)

    # get the histogram of features
    if hog_feat == True:
        # Call get_hog_features() with vis=False, feature_vec=True
        hog_features = []
        for channel in hog_channels:
            hog_features.append(get_hog_features(image[:, :, channel],
                                                 orient, pix_per_cell, cell_per_block,
                                                 vis=False, feature_vec=True))
        hog_features = np.ravel(hog_features)

    return np.concatenate((spatial_features, hist_features, hog_features))